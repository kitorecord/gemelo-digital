#!/usr/bin/env python
import os
import sys
import subprocess

if __name__ == "__main__":
    os.chdir(os.path.join(os.path.dirname(__file__), 'api'))
    sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'api'))
    os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'hospital_api.settings')
    from django.core.management import execute_from_command_line
    execute_from_command_line(sys.argv)
